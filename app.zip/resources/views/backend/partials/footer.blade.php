<footer class="footer py-4">
  <div class="container-fluid">
    <div class="d-block mx-auto">
      <p class="mb-0">{{ !is_null($footerTextInfo) ? $footerTextInfo->copyright_text : '' }}</p>
    </div>
  </div>
</footer>
